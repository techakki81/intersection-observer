import React,{useState,useMemo} from 'react'
import Child from './Child'

const Root = ({children}) => {
    console.log(`Root is executed`)
    const [state, setstate] = useState(0)
    const [state2, setstate2] = useState(10)

    let i = useMemo(() => 
    {
        console.log('memo called' + state2)

        return state2*3
    }, [state2])

    console.log(i)

    return ( 
      <div>
        
           <button onClick={()=>setstate( state=>state+1 )}>Increment</button>
           
           <button onClick={()=>setstate2( state2=>state2+1 )}>useMemo</button>

            <Child parentCount={state}></Child>
           
      </div>
    )
  }

export default Root