import React , {useState} from 'react'

const  Child =  ({parentCount})=>{
    console.log(`Child is executed`)
    const [state, setstate] = useState(0)

    return  ( 
      <div>
        Parent Count: {parentCount}
        Child counter: {state}
        <button onClick={()=>setstate(state+1)}>Inc Child Counter</button>
      </div>
    )
  }

export default React.memo( Child )
